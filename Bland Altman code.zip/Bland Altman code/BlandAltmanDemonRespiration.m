%% Generate paramteres for data generation
clear;
load('data_respiration.mat');

noise = 1/3000; % percent
npatients = 40; % number of patients
bias = 1; % slope bias

% Heart muscle territories per patient
territories = {'Respiration rate'};
nterritories = length(territories);
% Patient states during measurement
states = {'15 RPM - Test', '18 RPM - Test'};
nstates = length(states);

% Real flow values
%restFlow = 25*(1+0.1*randn(npatients,nterritories));
%stressFlow = 25*(1+0.1*randn(npatients,nterritories));
twofive = 25+2*0.01*randn(npatients,nterritories);
%twoseven = 27+2*0.01*randn(npatients,nterritories);
%unu = 25+2*0.00001*randn(npatients,nterritories);

restFlow_prosim = [14; 14; 14; 15.0; 15; 15; 15; 15.0; 15; 15.0;
           15; 15.0; 15.0; 15; 15.0; 15.0; 15.0; 14.9; 14; 15.0;
           15; 14; 15; 15.0; 15.0; 15.0; 15.0; 15.1; 15.0; 14;
           15.0; 15.0; 15.0; 14; 15.0; 15.0; 15.0; 15.0; 15.0; 15.0];

stressFlow_prosim = [17.0; 17.0; 17; 17; 16; 16; 17.0; 17.0; 17.0; 17.0;
           17.0; 16; 17.0; 16; 17.0; 17.0; 17.0; 17.0; 17; 17.0;
           17.0; 17; 17; 17.0; 17; 17.0; 17.0; 17; 17.0; 17.0;
           17.0; 17.0; 17.0; 17.0; 17.0; 17.1; 17.0; 17.0; 17.0; 17.0]

restFlow_corsano = [14.91;14.86;14.92;14.98;15.07;15.13;15.03;14.97;15.11;15.03;15.09;15.01;14.99;15.12;14.96;14.99;14.97;14.86;14.86;15.03;15.12;14.88;15.09;14.97;14.97;14.96;14.95;15.09;15.01;14.89;15.00;14.99;14.99;14.90;15.02;14.97;14.97;14.97;14.98;15.04]

stressFlow_corsano = [16.96;17.00;17.11;17.10;16.91;16.92;16.99;17.01;17.01;17.01;16.98;16.90;17.04;16.89;17.00;16.97;17.03;16.97;17.09;16.96;16.99;17.04;17.06;17.00;17.15;16.96;16.95;17.12;17.03;16.95;17.01;16.97;16.99;17.01;16.98;17.08;17.03;16.99;17.03;16.99]


%% Example 1
% Baseline data with noise
datax = cat(2,  restFlow_prosim, stressFlow_prosim);
% Follow-up data with noise and a bias
datay = cat(2,  restFlow_corsano, stressFlow_corsano);

% BA plot parameters
tit = 'Respiration rate Repeatability'; % figure title
gnames = {territories, states}; % names of groups in data {dimension 1 and 2}
label = {'Prosim8','Corsano','RPM'}; % Names of data sets
corrinfo = {'n','SSE','r2','eq'}; % stats to display of correlation scatter plot
BAinfo = {'RPC(RPM)','ks'}; % stats to display on Bland-ALtman plot
limits = 'auto'; % how to set the axes limits
if 1 % colors for the data sets may be set as:
	colors = 'br';      % character codes
else
	colors = [0 0 1;... % or RGB triplets
		      1 0 0];
end

% Generate figure with symbols
[cr, fig, statsStruct] = BlandAltman(datax, datay,label,tit,gnames,'corrInfo',corrinfo,'baInfo',BAinfo,'axesLimits',limits,'colors',colors, 'showFitCI',' on');

% Generate figure with numbers of the data points (patients) and fixed
% Bland-Altman difference data axes limits
BlandAltman(datax, datay,label,[tit ' (numbers, forced 0 intercept, and fixed BA y-axis limits)'],gnames,'corrInfo',corrinfo,'axesLimits',limits,'colors',colors,'symbols','Num','baYLimMode','square','forceZeroIntercept','on')


% Generate figure with differences presented as percentages and confidence
% intervals on the correlation plot
BAinfo = {'RPC'};
BlandAltman(datax, datay,label,[tit ' (show fit confidence intervals and differences as percentages)'],gnames,'diffValueMode','percent', 'showFitCI','on','baInfo',BAinfo)


% Display statistical results that were returned from analyses
disp('Statistical results:');
disp(statsStruct);
% * Note that non-Gaussian warning may result for the first two analysis as
% the two data sets (rest and stress) make the difference data marginally
% Gaussian (two overlapping Gaussians). This should not be the case with
% the third analysis as it is in percent difference of the means.

%% Example 2 - using non-Gaussian data and one figure with 2 analyses
%disp('Analysis with non-Gaussian distribution data')
% Baseline data with non-Gaussian noise
%data1 = cat(3,  restFlow.*(1+noise*rand(npatients,nterritories)), stressFlow.*(1+noise*rand(npatients,nterritories)));
% Follow-up data with non-Gaussian noise and a bias
%data2 = bias * cat(3,  restFlow.*(1+noise*rand(npatients,nterritories)), stressFlow.*(1+noise*rand(npatients,nterritories)));

%figure('Color','w','Units','centimeters', 'Position',[2 2 20 20])
%ah1 = subplot(211);
%ah2 = subplot(212);

%BAinfo = {'RPC(%)','ks'};

%[cr, fig, statsStruct] = BlandAltman(ah1, data1, data2,label,[tit ' (inappropriate Gaussian stats)'],gnames,'corrInfo',corrinfo,'baInfo',BAinfo,'axesLimits',limits,'colors',colors);
% A warning should appear indicating detection of non-Gaussian
% distribution.

% Repeat analysis using non-parametric analysis, no warning should appear.
%BAinfo = {'RPCnp','ks'};
%[cr, fig, statsStruct] = BlandAltman(ah2, data1, data2,label,[tit ' (using non-parametric stats)'],gnames,'corrInfo',corrinfo,'baInfo',BAinfo,'axesLimits',limits,'colors',colors,'baStatsMode','non-parametric');
% Keep in mind that alpha is set to 0.05 so there is a 1/20 chace of false
% warnings.

