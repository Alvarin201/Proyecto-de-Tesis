load ECG_ProSim8
load ECG_Corsano


fs = 256;  % Frecuencia de muestreo en Hz
tiempoFinal = 240;  % Tiempo final en segundos de medicion en corsano

% Calcular el número de puntos de datos necesarios
numPuntos = tiempoFinal * fs;

dt = 1/fs;  % Intervalo de tiempo entre muestras en segundos


totalTime1 = (length(ECG_ProSim8()) - 1) * dt;  % Duración total de la muestra de ECG
t1 = 0:dt:totalTime1;  % Vector de tiempo desde 0 hasta el tiempo total

totalTime2 = (length(datosECG2()) - 1) * dt;  % Duración total de la muestra de ECG
t2 = 0:dt:totalTime2;  % Vector de tiempo desde 0 hasta el tiempo total

datosECG1 = data(34,1:numPuntos);
tiempoECG1 = t1(1:numPuntos);


tiempoECG2 = t2(1:numPuntos);

figure; % Crea una nueva figura
plot(tiempoECG1,datosECG1);
title('Señal de ECG');
xlabel('Tiempo');
ylabel('Amplitud');

figure; % Crea una nueva figura
plot(tiempoECG2,datosECG2);
title('Señal de ECG');
xlabel('Tiempo');
ylabel('Amplitud');

wt1 = modwt(datosECG1,5);
mra1 = modwtmra(wt1, 'sym4');

numLevels = 5; % Número de niveles de descomposición

figure; % Crea una nueva figura
for k = 1:numLevels
    subplot(numLevels, 1, k);
    plot(mra1(k, :)); % Grafica cada nivel de reconstrucción
    title(['Level ', num2str(k)]);
    xlabel('Time (s)');
    ylabel('Amplitude');
end
figure

wtrec1 = zeros(size(wt1));
wtrec1(4:5,:) = wt1(4:5,:);
y1 = imodwt(wtrec1,'sym4');
y1 = abs(y1).^2;
ecg_reconstruida1 = y1();

plot(tiempoECG1, ecg_reconstruida1);
set(gca,'xlim',[10.2 12])
title('Reconstructed ECG Signal from Levels 4 and 5');
xlabel('Time');
ylabel('Amplitude');

figure
plot(tiempoECG1,datosECG1,'k--')
hold on
plot(tiempoECG1,y1,'r','linewidth',1.5)
plot(tiempoECG1,abs(ecg_reconstruida1).^2,'b')
plot(tiempoECG1(numPuntos),ecg_reconstruida1(numPuntos),'ro','markerfacecolor',[1 0 0])
set(gca,'xlim',[10.2 12])
legend('Raw Data','Wavelet Reconstruction','Raw Data Squared', ...
    'Location','SouthEast');
xlabel('Time (s)')
ylabel('Amplitude')

wt2 = modwt(datosECG2,5);
mra2 = modwtmra(wt2, 'sym4');
wtrec2 = zeros(size(wt2));
wtrec2(4:5,:) = wt2(4:5,:);
y2 = imodwt(wtrec2,'sym4');
y2 = abs(y2).^2;
ecg_reconstruida2 = y2();

% Comparación visual
figure;
subplot(2, 1, 1);
plot(tiempoECG1, ecg_reconstruida1);
title('Reconstructed ProSim8 from Levels 4 and 5');
xlabel('Time (s)');
ylabel('Amplitude');
set(gca,'xlim',[10.2 12])

subplot(2, 1, 2);
plot(tiempoECG2, ecg_reconstruida2);
title('Reconstructed Corsano signal from Levels 4 and 5');
xlabel('Time (s)');
ylabel('Amplitude');
set(gca,'xlim',[10.2 12])

% Cálculo de la correlación
correlation = corrcoef(ecg_reconstruida1, ecg_reconstruida2);
disp('Correlation between reconstructed ECG signals:');
disp(correlation(1, 2));

% Análisis de energía
energy_rec_ecg1 = sum(ecg_reconstruida1.^2);
energy_rec_ecg2 = sum(ecg_reconstruida2.^2);

fprintf('Energy of reconstructed ECG1: %f\n', energy_rec_ecg1);
fprintf('Energy of reconstructed ECG2: %f\n', energy_rec_ecg2);

mad = mean(abs(ecg_reconstruida1 - ecg_reconstruida2));
fprintf('Diferencia Absoluta Media: %f\n', mad);

mse = mean((ecg_reconstruida1 - ecg_reconstruida2).^2);
fprintf('Error Cuadrático Medio: %f\n', mse);

std_diff = std(ecg_reconstruida1 - ecg_reconstruida2);
fprintf('Desviación Estándar de la Diferencia: %f\n', std_diff);

corr_coeff = corrcoef(ecg_reconstruida1, ecg_reconstruida2);
fprintf('Coeficiente de Correlación de Pearson: %f\n', corr_coeff(1,2));

figure;
subplot(2, 1, 1);
spectrogram(ecg_reconstruida1, 256, 250, 256, fs, 'yaxis');
title('Spectrogram of Reconstructed ProSim 8 Signal');

subplot(2, 1, 2);
spectrogram(ecg_reconstruida2, 256, 250, 256, fs, 'yaxis');
title('Spectrogram of Reconstructed Corsano Signal');

fft_ecg1 = fft(ecg_reconstruida1);
fft_ecg2 = fft(ecg_reconstruida2);
correlation_spectrum = corrcoef(abs(fft_ecg1), abs(fft_ecg2));
fprintf('Correlación entre los espectros de frecuencia: %f\n', correlation_spectrum(1, 2));

